jQuery(document).ready(function ($) {
    window.scpSitePresenceState = window.scpSitePresenceState || {};

    function collectSteamIds() {
        const steamIds = [];
        $('.scp-user-card, .scp-public-card-pro').each(function () {
            const id = $(this).data('steamid');
            if (id && steamIds.indexOf(String(id)) === -1) {
                steamIds.push(String(id));
            }
        });
        return steamIds;
    }

    function collectSiteUserIds() {
        const userIds = [];
        $('[data-scp-site-user-id]').each(function () {
            const id = Number($(this).data('scp-site-user-id') || 0);
            if (id > 0 && userIds.indexOf(String(id)) === -1) {
                userIds.push(String(id));
            }
        });
        return userIds;
    }

    function applySitePresence(userId, isOnline) {
        const wrappers = $('[data-scp-site-user-id="' + userId + '"]');
        wrappers.each(function () {
            const dot = $(this).find('.scp-site-presence-dot').first();
            if (!dot.length) return;

            dot.removeClass('online offline').addClass(isOnline ? 'online' : 'offline');
            dot.attr('data-tooltip', isOnline ? 'آنلاین در سایت' : 'آفلاین در سایت');
        });

        window.scpSitePresenceState[String(userId)] = !!isOnline;
    }

    function pingCurrentUserPresence() {
        if (!scpAjax.current_user_id) return;

        $.post(scpAjax.ajax_url, {
            action: 'scp_ping_site_presence',
            nonce: scpAjax.nonce
        });
    }

    function updateSitePresence() {
        const userIds = collectSiteUserIds();
        if (userIds.length === 0) return;

        $.post(scpAjax.ajax_url, {
            action: 'scp_get_site_presence',
            user_ids: userIds.join(','),
            nonce: scpAjax.nonce
        }, function (response) {
            if (!(response && response.success && response.data)) return;

            $.each(response.data, function (userId, payload) {
                const online = !!(payload && payload.online);
                applySitePresence(String(userId), online);
            });

            if (window.dispatchEvent) {
                window.dispatchEvent(new CustomEvent('scp:site-presence-updated', { detail: window.scpSitePresenceState }));
            }
        });
    }

    function updateSteamPresence() {
        const steamIds = collectSteamIds();
        if (steamIds.length === 0) return;

        $.post(scpAjax.ajax_url, {
            action: 'scp_check_online_status',
            steamids: steamIds.join(','),
            nonce: scpAjax.nonce
        }, function (response) {
            if (!(response && response.success && response.data)) return;

            $.each(response.data, function (steamid, payload) {
                const data = (typeof payload === 'string')
                    ? { status: payload, current_game_name: '', current_game_image: '' }
                    : payload;

                const status = data.status === 'Online' ? 'Online' : 'Offline';

                const listStatusEl = $('.scp-user-card[data-steamid="' + steamid + '"] .scp-online-status');
                if (listStatusEl.length) {
                    listStatusEl.text(status);
                    listStatusEl.removeClass('online offline').addClass(status === 'Online' ? 'online' : 'offline');
                    listStatusEl.attr('data-tooltip', 'in steam');
                }

                const profileStatusEl = $('.scp-public-card-pro[data-steamid="' + steamid + '"] .scp-online-status-profile');
                if (profileStatusEl.length) {
                    profileStatusEl.text(status);
                    profileStatusEl.removeClass('online offline').addClass(status === 'Online' ? 'online' : 'offline');
                    profileStatusEl.attr('data-tooltip', 'in steam');
                }

                const profileCard = $('.scp-public-card-pro[data-steamid="' + steamid + '"]');
                if (profileCard.length) {
                    const gameNameEl = profileCard.find('.scp-current-game-name');
                    const gameImageEl = profileCard.find('.scp-current-game-cover');
                    const hasGame = !!(data.current_game_name && data.current_game_name.length);

                    gameNameEl.text(hasGame ? data.current_game_name : 'در حال حاضر بازی‌ای در حال اجرا نیست');

                    if (hasGame && data.current_game_image) {
                        gameImageEl.attr('src', data.current_game_image)
                            .attr('alt', data.current_game_name)
                            .removeClass('is-hidden');
                    } else {
                        gameImageEl.addClass('is-hidden');
                    }
                }
            });
        });
    }

    function refreshAllPresence() {
        pingCurrentUserPresence();
        updateSitePresence();
        updateSteamPresence();
    }

    refreshAllPresence();
    setInterval(refreshAllPresence, 3000);
});

// حذف نامک بعد ریدایرکت از استیم
if (window.history.replaceState) {
  const url = new URL(window.location);
  url.searchParams.delete('steam_connected');
  url.searchParams.delete('steam_login_success');
  url.searchParams.delete('steam_register_success');
  url.searchParams.delete('steam_disconnected');
  url.searchParams.delete('steam_error');
  url.searchParams.delete('steam_already_registered');
  window.history.replaceState({}, document.title, url.pathname + url.search);
}

// فید کردن پیام های استیم
(function(){
  const el = document.getElementById('scp-sticky-error');
  if(el){
    setTimeout(() => {
      el.classList.add('scp-show');
    }, 50);

    setTimeout(() => {
      el.classList.remove('scp-show');
      el.classList.add('scp-hide');
      setTimeout(() => el.remove(), 500);
    }, 10000);
  }
})();
