(function () {
    if (!window.scpAjax || !scpAjax.ajax_url || !scpAjax.current_user_id) {
        return;
    }

    const UNREAD_STORAGE_KEY = `scp_chat_seen_${scpAjax.current_user_id}`;

    const state = {
        activeRoomId: 0,
        activeUser: null,
        lastMessageId: 0,
        pollTimer: null,
        autoOpenSignature: '',
        latestRooms: [],
    };

    const request = async (action, payload) => {
        const body = new URLSearchParams({ action, nonce: scpAjax.nonce, ...payload });
        const res = await fetch(scpAjax.ajax_url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: body.toString(),
            credentials: 'same-origin',
        });
        const data = await res.json();
        if (!data.success) throw new Error((data.data && data.data.message) || 'request_failed');
        return data.data;
    };

    const getSeenMap = () => {
        try {
            const raw = localStorage.getItem(UNREAD_STORAGE_KEY);
            return raw ? JSON.parse(raw) : {};
        } catch (err) {
            return {};
        }
    };

    const setSeenMap = (map) => {
        try {
            localStorage.setItem(UNREAD_STORAGE_KEY, JSON.stringify(map));
        } catch (err) {
            // Ignore storage failures.
        }
    };

    const getLatestMessageAt = (messages) => {
        if (!Array.isArray(messages) || !messages.length) {
            return null;
        }

        const last = messages[messages.length - 1];
        return last && last.created_at ? String(last.created_at) : null;
    };

    const markRoomAsSeen = (roomId, lastMessageAt) => {
        if (!roomId || !lastMessageAt) {
            return;
        }

        const seen = getSeenMap();
        seen[String(roomId)] = String(lastMessageAt);
        setSeenMap(seen);
    };

    const hasUnreadRoom = (room) => {
        if (!room || !room.room_id || !room.last_message_at) {
            return false;
        }

        const seen = getSeenMap();
        const seenAt = seen[String(room.room_id)] || '';
        return seenAt < String(room.last_message_at);
    };

    const getUnreadRooms = (rooms) => (Array.isArray(rooms) ? rooms.filter(hasUnreadRoom) : []);

    const verifiedBadgeHtml = (isVerified) => {
        if (!isVerified) {
            return '';
        }

        return '<span class="scp-verified-badge scp-verified-badge-inline" role="img" aria-label="احراز هویت شده"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 2.5 9.3 4.7l-3.4-.1-.8 3.3-2.6 2.1 1.4 3-1.4 3 2.6 2.1.8 3.3 3.4-.1 2.7 2.2 2.7-2.2 3.4.1.8-3.3 2.6-2.1-1.4-3 1.4-3-2.6-2.1-.8-3.3-3.4.1L12 2.5Zm-1 14.4-3.2-3.2 1.4-1.4 1.8 1.8 4.2-4.2 1.4 1.4-5.6 5.6Z"></path></svg><span class="scp-verified-tooltip">احراز هویت شده</span></span>';
    };



    const getPresenceMeta = (userId) => {
        const id = String(Number(userId) || 0);
        const isOnline = !!(window.scpSitePresenceState && window.scpSitePresenceState[id]);
        return {
            className: isOnline ? 'online' : 'offline',
            tooltip: isOnline ? 'آنلاین در سایت' : 'آفلاین در سایت',
        };
    };

    const refreshThreadPresenceDots = (container) => {
        if (!container) {
            return;
        }

        container.querySelectorAll('.scp-chat-msg .scp-site-presence-dot').forEach((dot) => dot.remove());

        const latestAvatarByUser = new Map();
        container.querySelectorAll('.scp-chat-msg .scp-avatar-presence-wrap[data-scp-site-user-id]').forEach((wrapper) => {
            const userId = String(Number(wrapper.dataset.scpSiteUserId || 0));
            if (userId !== '0') {
                latestAvatarByUser.set(userId, wrapper);
            }
        });

        latestAvatarByUser.forEach((wrapper, userId) => {
            const presenceMeta = getPresenceMeta(userId);
            const dot = document.createElement('span');
            dot.className = `scp-site-presence-dot ${presenceMeta.className}`;
            dot.setAttribute('data-tooltip', presenceMeta.tooltip);
            wrapper.appendChild(dot);
        });
    };

    const createMessageNode = (message) => {
        const mine = Number(message.sender_id) === Number(scpAjax.current_user_id);
        const profileUrl = (message.sender && message.sender.public_profile_url) ? message.sender.public_profile_url : '#';
        const isSenderVerified = !!(message.sender && message.sender.is_verified);
        const hasProfileUrl = profileUrl !== '#';
        const div = document.createElement('div');
        div.className = `scp-chat-msg ${mine ? 'is-me' : 'is-them'}`;
        div.dataset.id = message.id;
        div.dataset.senderId = String(Number(message.sender.id || 0));
        div.dataset.senderVerified = isSenderVerified ? '1' : '0';
        div.innerHTML = `
            <a class="scp-chat-msg-user-link" href="${profileUrl}" ${hasProfileUrl ? '' : 'aria-disabled="true" tabindex="-1"'}>
                <span class="scp-avatar-presence-wrap" data-scp-site-user-id="${Number(message.sender.id || 0)}"><img src="${message.sender.avatar}" alt="${message.sender.name}"></span>
            </a>
            <div class="scp-chat-msg-body">
                <strong><a class="scp-chat-msg-user-name" href="${profileUrl}" ${hasProfileUrl ? '' : 'aria-disabled="true" tabindex="-1"'}>${message.sender.name}</a></strong>
                <p>${message.message}</p>
            </div>
        `;
        return div;
    };

    const refreshThreadVerificationBadges = (container) => {
        if (!container) {
            return;
        }

        container.querySelectorAll('.scp-chat-msg-body .scp-verified-badge').forEach((node) => node.remove());

        const latestByUser = new Map();
        container.querySelectorAll('.scp-chat-msg[data-sender-id]').forEach((msgNode) => {
            const senderId = String(msgNode.dataset.senderId || '0');
            if (senderId !== '0') {
                latestByUser.set(senderId, msgNode);
            }
        });

        latestByUser.forEach((msgNode) => {
            if (String(msgNode.dataset.senderVerified || '0') !== '1') {
                return;
            }

            const strong = msgNode.querySelector('.scp-chat-msg-body strong');
            if (!strong) {
                return;
            }

            strong.insertAdjacentHTML('beforeend', verifiedBadgeHtml(true));
        });
    };

    const renderThread = (container, messages) => {
        container.innerHTML = '';
        messages.forEach((msg) => {
            state.lastMessageId = Math.max(state.lastMessageId, Number(msg.id));
            container.appendChild(createMessageNode(msg));
        });
        refreshThreadPresenceDots(container);
        refreshThreadVerificationBadges(container);
        container.scrollTop = container.scrollHeight;
    };

    const appendMessages = (container, messages) => {
        if (!messages.length) {
            return;
        }

        messages.forEach((msg) => {
            state.lastMessageId = Math.max(state.lastMessageId, Number(msg.id));
            container.appendChild(createMessageNode(msg));
        });
        refreshThreadPresenceDots(container);
        refreshThreadVerificationBadges(container);
        container.scrollTop = container.scrollHeight;
    };

    const mountWidget = () => {
        const widget = document.getElementById('scp-chat-widget');
        if (!widget) {
            return null;
        }

        widget.innerHTML = `
            <div class="scp-chat-panel" hidden>
                <div class="scp-chat-panel-header">
                    <span class="scp-chat-title"></span>
                    <button type="button" class="scp-chat-close">×</button>
                </div>
                <div class="scp-chat-unread-switcher" hidden></div>
                <div class="scp-chat-messages"></div>
                <form class="scp-chat-send-form">
                    <input type="text" maxlength="1000" placeholder="پیام..." required>
                    <button type="submit">ارسال</button>
                </form>
            </div>
        `;

        const panel = widget.querySelector('.scp-chat-panel');
        const title = widget.querySelector('.scp-chat-title');
        const close = widget.querySelector('.scp-chat-close');
        const unreadSwitcher = widget.querySelector('.scp-chat-unread-switcher');
        const messagesBox = widget.querySelector('.scp-chat-messages');
        const form = widget.querySelector('.scp-chat-send-form');
        const input = form.querySelector('input');
        const submitBtn = form.querySelector('button[type="submit"]');

        const applyUnreadStyles = () => {
            if (document.getElementById('scp-chat-unread-inline-style')) {
                return;
            }

            const style = document.createElement('style');
            style.id = 'scp-chat-unread-inline-style';
            style.textContent = `
                .scp-chat-unread-switcher {
                    display: flex;
                    gap: 6px;
                    padding: 8px 10px;
                    border-bottom: 1px solid rgba(255,255,255,.08);
                    overflow-x: auto;
                    white-space: nowrap;
                }
                .scp-chat-unread-chip {
                    border: 1px solid rgba(255,255,255,.2);
                    background: rgba(255,255,255,.08);
                    color: #fff;
                    border-radius: 999px;
                    padding: 4px 10px 4px 6px;
                    font-size: 12px;
                    cursor: pointer;
                    display: inline-flex;
                    align-items: center;
                    gap: 6px;
                }
                .scp-chat-unread-chip.is-active {
                    background: #2ea44f;
                    border-color: #2ea44f;
                }
                .scp-chat-unread-chip-avatar {
                    width: 22px;
                    height: 22px;
                    border-radius: 50%;
                    object-fit: cover;
                    flex: 0 0 22px;
                }
                .scp-chat-unread-chip-name {
                    display: inline-flex;
                    align-items: center;
                    gap: 4px;
                    max-width: 150px;
                    min-width: 0;
                }
                .scp-chat-unread-chip-name-text {
                    display: inline-block;
                    min-width: 0;
                    max-width: 126px;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
                .scp-chat-unread-chip-name .scp-verified-badge {
                    margin-inline-start: 0;
                    flex: 0 0 auto;
                }
            `;
            document.head.appendChild(style);
        };

        const renderUnreadSwitcher = (rooms) => {
            const unreadRooms = getUnreadRooms(rooms);
            if (!unreadRooms.length) {
                unreadSwitcher.hidden = true;
                unreadSwitcher.innerHTML = '';
                return;
            }

            unreadSwitcher.hidden = false;
            unreadSwitcher.innerHTML = unreadRooms.map((room) => {
                const active = Number(room.room_id) === Number(state.activeRoomId) ? ' is-active' : '';
                const name = (room.other_user && room.other_user.name) ? room.other_user.name : 'Chat';
                const avatar = (room.other_user && room.other_user.avatar) ? room.other_user.avatar : '';
                const badge = verifiedBadgeHtml(!!(room.other_user && room.other_user.is_verified));
                return `<button type="button" class="scp-chat-unread-chip${active}" data-room-id="${room.room_id}" data-user-id="${room.other_user.id}" data-user-name="${name}">
                    <span class="scp-avatar-presence-wrap" data-scp-site-user-id="${Number(room.other_user.id || 0)}"><img class="scp-chat-unread-chip-avatar" src="${avatar}" alt="${name}"><span class="scp-site-presence-dot offline" data-tooltip="آفلاین در سایت"></span></span>
                    <span class="scp-chat-unread-chip-name"><span class="scp-chat-unread-chip-name-text">${name}</span>${badge}</span>
                </button>`;
            }).join('');
        };

        const refreshRooms = async () => {
            const data = await request('scp_chat_get_rooms', {});
            state.latestRooms = data.rooms || [];
            renderUnreadSwitcher(state.latestRooms);
            return state.latestRooms;
        };

        const openRoomByTarget = async (targetUserId, targetName, options = {}) => {
            const openOptions = Object.assign({ markSeen: true }, options || {});
            const data = await request('scp_chat_open_room', { target_user_id: targetUserId });
            state.activeRoomId = Number(data.room_id);
            state.lastMessageId = 0;
            state.activeUser = targetName;
            title.textContent = `${scpAjax.labels.chat_with} ${targetName}`;
            renderThread(messagesBox, data.messages || []);
            panel.hidden = false;

            const lastMessageAt = getLatestMessageAt(data.messages || []);
            if (openOptions.markSeen && lastMessageAt) {
                markRoomAsSeen(state.activeRoomId, lastMessageAt);
            }

            if (state.pollTimer) {
                clearInterval(state.pollTimer);
            }

            state.pollTimer = setInterval(async () => {
                if (!state.activeRoomId || panel.hidden) {
                    return;
                }

                try {
                    const fresh = await request('scp_chat_fetch_messages', { room_id: state.activeRoomId, after_id: state.lastMessageId });
                    appendMessages(messagesBox, fresh.messages || []);

                    const newestAt = getLatestMessageAt(fresh.messages || []);
                    if (newestAt) {
                        markRoomAsSeen(state.activeRoomId, newestAt);
                    }

                    await refreshRooms();
                } catch (err) {
                    console.error(err);
                }
            }, 3500);

            await refreshRooms();
        };

        const maybeAutoOpenUnread = async () => {
            const rooms = await refreshRooms();

            if (!panel.hidden) {
                return;
            }

            const unreadRooms = getUnreadRooms(rooms);
            const firstUnread = unreadRooms[0];
            if (!firstUnread || !firstUnread.other_user) {
                return;
            }

            const signature = `${firstUnread.room_id}:${firstUnread.last_message_at || ''}`;
            if (signature === state.autoOpenSignature) {
                return;
            }

            state.autoOpenSignature = signature;
            await openRoomByTarget(firstUnread.other_user.id, firstUnread.other_user.name || '', { markSeen: false });
        };

        applyUnreadStyles();

        close.addEventListener('click', () => {
            panel.hidden = true;
        });

        unreadSwitcher.addEventListener('click', (e) => {
            const chip = e.target.closest('.scp-chat-unread-chip');
            if (!chip) {
                return;
            }

            openRoomByTarget(chip.dataset.userId, chip.dataset.userName || '').catch(console.error);
        });

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const message = input.value.trim();
            if (!message || !state.activeRoomId || (submitBtn && submitBtn.disabled)) {
                return;
            }

            input.disabled = true;
            if (submitBtn) {
                submitBtn.disabled = true;
            }
            try {
                const data = await request('scp_chat_send_message', { room_id: state.activeRoomId, message });
                if (data.message) {
                    appendMessages(messagesBox, [data.message]);

                    if (data.message.created_at) {
                        markRoomAsSeen(state.activeRoomId, data.message.created_at);
                    }
                }
                input.value = '';
                await refreshRooms();
            } catch (err) {
                console.error(err);
            } finally {
                input.disabled = false;
                if (submitBtn) {
                    submitBtn.disabled = false;
                }
                input.focus();
            }
        });

        document.addEventListener('click', (e) => {
            const btn = e.target.closest('.scp-chat-launch');
            if (!btn) {
                return;
            }

            e.preventDefault();
            openRoomByTarget(btn.dataset.targetUser, btn.dataset.targetName || '').catch(console.error);
        });

        maybeAutoOpenUnread().catch(console.error);

        setInterval(() => {
            maybeAutoOpenUnread().catch(console.error);
        }, 5000);

        return { openWithUser: openRoomByTarget };
    };

    const mountRoomsPage = () => {
        const page = document.getElementById('scp-chat-page');
        if (!page) {
            return;
        }

        const list = page.querySelector('[data-scp-chat-room-list]');
        const thread = page.querySelector('[data-scp-chat-thread]');
        const placeholder = page.querySelector('.scp-chat-thread-placeholder');
        const form = page.querySelector('[data-scp-chat-form]');
        const input = form.querySelector('input[name="message"]');
        const submitBtn = form.querySelector('button[type="submit"]');

        const setActiveRoomItem = (roomId) => {
            const items = list.querySelectorAll('.scp-room-item');
            items.forEach((el) => {
                const active = Number(el.dataset.roomId) === Number(roomId);
                el.classList.toggle('is-active', active);
                if (active) {
                    el.setAttribute('aria-current', 'true');
                } else {
                    el.removeAttribute('aria-current');
                }
            });
        };

        const openRoom = async (roomId, roomName) => {
            state.activeRoomId = Number(roomId);
            state.lastMessageId = 0;
            placeholder.hidden = true;
            thread.hidden = false;
            form.hidden = false;
            thread.dataset.roomName = roomName;
            thread.innerHTML = '';
            const data = await request('scp_chat_fetch_messages', { room_id: roomId, after_id: 0 });
            renderThread(thread, data.messages || []);
            setActiveRoomItem(roomId);

            const latestAt = getLatestMessageAt(data.messages || []);
            if (latestAt) {
                markRoomAsSeen(roomId, latestAt);
            }
        };

        const loadRooms = async () => {
            const data = await request('scp_chat_get_rooms', {});
            const rooms = data.rooms || [];
            if (!rooms.length) {
                list.innerHTML = `<p class="scp-chat-empty">${scpAjax.labels.no_rooms}</p>`;
                return;
            }

            list.innerHTML = rooms.map((room) => `
                <button type="button" class="scp-room-item" data-room-id="${room.room_id}" data-room-name="${room.other_user.name}">
                    <span class="scp-avatar-presence-wrap" data-scp-site-user-id="${Number(room.other_user.id || 0)}"><img src="${room.other_user.avatar}" alt="${room.other_user.name}"><span class="scp-site-presence-dot offline" data-tooltip="آفلاین در سایت"></span></span>
                    <span class="scp-room-item-content">
                        <strong><a class="scp-room-user-name" href="${room.other_user.public_profile_url || ('/?scp_site_user=' + room.other_user.id)}" title="${room.other_user.name}">${room.other_user.name}</a>${verifiedBadgeHtml(!!room.other_user.is_verified)}</strong>
                        <small title="${room.last_message || ''}">${room.last_message || ''}</small>
                    </span>
                </button>
            `).join('');

            if (state.activeRoomId) {
                setActiveRoomItem(state.activeRoomId);
            }
        };

        list.addEventListener('click', (e) => {
            const item = e.target.closest('.scp-room-item');
            if (!item) {
                return;
            }

            openRoom(item.dataset.roomId, item.dataset.roomName).catch(console.error);
        });

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const message = input.value.trim();
            if (!state.activeRoomId || !message || (submitBtn && submitBtn.disabled)) {
                return;
            }

            input.disabled = true;
            if (submitBtn) {
                submitBtn.disabled = true;
            }

            try {
                const res = await request('scp_chat_send_message', { room_id: state.activeRoomId, message });
                if (res.message) {
                    appendMessages(thread, [res.message]);
                    if (res.message.created_at) {
                        markRoomAsSeen(state.activeRoomId, res.message.created_at);
                    }
                }

                input.value = '';
                await loadRooms();
            } catch (err) {
                console.error(err);
            } finally {
                input.disabled = false;
                if (submitBtn) {
                    submitBtn.disabled = false;
                }
                input.focus();
            }
        });

        setInterval(async () => {
            if (!state.activeRoomId) {
                return;
            }

            const fresh = await request('scp_chat_fetch_messages', { room_id: state.activeRoomId, after_id: state.lastMessageId });
            appendMessages(thread, fresh.messages || []);

            const latestAt = getLatestMessageAt(fresh.messages || []);
            if (latestAt) {
                markRoomAsSeen(state.activeRoomId, latestAt);
            }
        }, 3500);

        loadRooms().catch(console.error);
    };

    mountWidget();
    mountRoomsPage();
})();
