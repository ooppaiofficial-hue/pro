<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('scp_is_user_identity_verified')) {
    /**
     * Check whether a user is identity-verified by Gaming User Dashboard plugin.
     */
    function scp_is_user_identity_verified($user_id) {
        $user_id = absint($user_id);
        if ($user_id <= 0) {
            return false;
        }

        $status = (string) get_user_meta($user_id, 'gud_verification_status', true);
        return $status === 'approved';
    }
}

if (!function_exists('scp_get_verified_badge_html')) {
    /**
     * Render a YouTube-style verification badge for approved users.
     */
    function scp_get_verified_badge_html($user_id, $args = []) {
        if (!scp_is_user_identity_verified($user_id)) {
            return '';
        }

        $args = wp_parse_args($args, [
            'class' => '',
            'label' => 'احراز هویت شده',
        ]);

        $class_tokens = preg_split('/\s+/', (string) $args['class']);
        $class_tokens = array_filter(array_map('sanitize_html_class', (array) $class_tokens));
        $badge_classes = trim('scp-verified-badge ' . implode(' ', $class_tokens));
        $label = (string) $args['label'];

        return sprintf(
            '<span class="%1$s" role="img" aria-label="%2$s"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 2.5 9.3 4.7l-3.4-.1-.8 3.3-2.6 2.1 1.4 3-1.4 3 2.6 2.1.8 3.3 3.4-.1 2.7 2.2 2.7-2.2 3.4.1.8-3.3 2.6-2.1-1.4-3 1.4-3-2.6-2.1-.8-3.3-3.4.1L12 2.5Zm-1 14.4-3.2-3.2 1.4-1.4 1.8 1.8 4.2-4.2 1.4 1.4-5.6 5.6Z"></path></svg><span class="scp-verified-tooltip">%2$s</span></span>',
            esc_attr($badge_classes),
            esc_attr($label)
        );
    }
}
